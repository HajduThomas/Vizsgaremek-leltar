﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnnaKisBolt
{
    internal class gyorskodlesok
    {
        /*
        Tábla hozzáadás:
        CREATE TABLE tejtermek ( 
        id INT PRIMARY KEY AUTO_INCREMENT, 
        nev VARCHAR(100) NOT NULL, 
        mennyiseg INT NOT NULL, 
        mennyiseg_jele VARCHAR(100) NOT NULL, 
        darabszam INT NOT NULL DEFAULT 0 
        )

        Termék hozzáadása:
        INSERT INTO tejtermek (nev, mennyiseg, mennyiseg_jele)
        VALUES
        ('Ferrero Kinder Maxi King', '35', 'g'),
        ('Ferrero Kinder Pingu Tejszelet', '30', 'g');
         */
    }
}
